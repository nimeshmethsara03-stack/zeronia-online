# Asset credits

- Hero/editorial gift-box photograph: Foldabox, “Navy Blue Luxury Folding Gift Boxes”, sourced from https://www.foldabox.co.uk/collections/navy-blue-gift-boxes . Used as a replaceable promotional placeholder for this implementation; no product sold by ZERONIA is represented by this image. Replace it with ZERONIA-owned campaign photography before final brand publication if redistribution rights are not confirmed.
- Marcellus and DM Sans: Google Fonts, SIL Open Font License. https://fonts.google.com/specimen/Marcellus and https://fonts.google.com/specimen/DM+Sans
- Supabase browser client: Supabase, MIT License. Bundled locally from `@supabase/supabase-js` 2.49.1.
- Interface icons: original inline SVG paths supplied with the project.
- Product records in `supabase/schema.sql` are editable starter samples without product photographs; replace them with actual store inventory.
