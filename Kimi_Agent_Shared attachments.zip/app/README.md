# ZERONIA Gift & Accessories

A deployable multi-page online store for ZERONIA in Nawalapitiya, Sri Lanka. Built with HTML5, CSS3, vanilla JavaScript and Supabase PostgreSQL/Auth/Storage/Edge Functions.

## Start locally

```bash
npm start
```

Open `http://localhost:3000`. No package installation or build step is required.

Before accepting real orders, complete **`SETUP_SINHALA.md`**: run `supabase/schema.sql`, add your public Supabase URL and publishable/anon key to `assets/js/config.js`, create and authorize an administrator, then deploy `create-order`.

## Main files

- `index.html`, `catalog.html`, `product.html` — storefront and live database catalog
- `cart.html`, `checkout.html`, `confirmation.html` — persistent browser cart and secure COD checkout
- `admin.html` — authorized admin dashboard
- `assets/css/styles.css` — responsive navy/gold design
- `assets/js/` — customer, cart, admin and Supabase modules
- `supabase/schema.sql` — tables, seed data, RLS, Storage policies, atomic order transaction and rate limiter
- `supabase/functions/create-order/index.ts` — server-side validation and order creation
- `server.js`, `Dockerfile` — production static hosting for the HTML application

## Security notes

Only public publishable/legacy-anon credentials belong in `assets/js/config.js`. Never put a secret/service-role key in browser files. Products, prices and stock are verified by the server; order totals are calculated by PostgreSQL. Orders and order items are admin-only. Cart contents are browser-local by design, while products, uploaded images, settings and submitted orders persist in Supabase.

Online card payments are intentionally disabled. WhatsApp opens a prepared message only after database confirmation; the customer must press Send.
