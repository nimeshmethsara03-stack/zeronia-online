# ZERONIA වෙබ් අඩවිය — සරල සිංහල Setup මාර්ගෝපදේශය

මේ මාර්ගෝපදේශය coding පළපුරුද්දක් නැති අයෙකුට එක පියවරකින් එක පියවරට යා හැකි ලෙස සකස් කර ඇත. පියවර අතරමඟ නවත්වන්න. **Supabase සකස් නොකර website එකේ products හෝ orders ක්‍රියා නොකරයි.** එය අනිවාර්ය පියවරකි.

## 1. මුලින්ම අවශ්‍ය මෘදුකාංග සකස් කිරීම

### VS Code

1. [code.visualstudio.com](https://code.visualstudio.com/) වෙත යන්න.
2. ඔබේ Windows / Mac පරිගණකයට ගැලපෙන **Download** බොත්තම ඔබන්න.
3. Download වූ file එක open කර default options සහිතව install කරන්න.

### Node.js

1. [nodejs.org](https://nodejs.org/) වෙත යන්න.
2. **LTS** ලෙස සඳහන් version එක download කර install කරන්න.
3. VS Code open කර, ඉහළ menu එකේ **Terminal → New Terminal** තෝරන්න.
4. පහත command එක type කර Enter ඔබන්න.

```bash
node --version
```

`v20` හෝ ඊට වැඩි version number එකක් පෙනුනොත් Node.js සාර්ථකව install වී ඇත.

## 2. Project එක VS Code වලින් විවෘත කිරීම

1. ZERONIA project folder එක ඔබේ පරිගණකයේ ලෙඛනගත කර පහසු තැනක තබන්න.
2. VS Code විවෘත කරන්න.
3. **File → Open Folder** තෝරන්න.
4. `app` folder එක තෝරා **Select Folder** ඔබන්න. එය තුළ `index.html`, `admin.html`, `package.json` තිබිය යුතුය.
5. වම් පැත්තේ Explorer තුළ files දිස්වේ.
6. **Terminal → New Terminal** ඔබන්න.

## 3. Supabase project එකක් සෑදීම

1. [supabase.com](https://supabase.com/) වෙත ගොස් account එකක් සාදා sign in කරන්න.
2. **New Project** ඔබන්න.
3. Project name ලෙස `zeronia-store` යොදන්න.
4. ශක්තිමත් database password එකක් සාදා ආරක්ෂිත ස්ථානයක සටහන් කරන්න. එය frontend code තුළ යොදන්න එපා.
5. ඔබට සමීප region එකක් තෝරන්න.
6. **Create new project** ඔබා project එක සෑදීම අවසන් වන තුරු රැඳී සිටින්න.

## 4. Database tables, Security Policies සහ Storage සකස් කිරීම

1. VS Code Explorer එකේ `supabase → schema.sql` file එක open කරන්න.
2. එහි සම්පූර්ණ අන්තර්ගතය select කර copy කරන්න. (`Ctrl+A`, පසුව `Ctrl+C`; Mac නම් `Cmd+A`, `Cmd+C`)
3. Supabase Dashboard එකේ **SQL Editor** වෙත යන්න.
4. **New Query** ඔබන්න.
5. Copy කළ SQL සම්පූර්ණයෙන් paste කර **Run** ඔබන්න.
6. **Success** පණිවිඩයක් ලැබිය යුතුය.
7. **Table Editor** විවෘත කර `categories`, `products`, `orders`, `order_items`, `authorized_admins`, `store_settings` tables ඇති බව පරීක්ෂා කරන්න.
8. `categories` table එකේ categories 9ක් සහ `products` table එකේ editable sample products 9ක් දිස්වේ.
9. **Storage** වෙත ගොස් `product-images` සහ `site-assets` buckets දෙක ඇති බව පරීක්ෂා කරන්න.

**වැදගත්:** SQL එක නැවත run කිරීමට සැලසුම් කර ඇත්තේ existing data මකා දමන්නේ නැති ලෙසයි. එහෙත් ඔබම SQL වෙනස් කළේ නම් නැවත run කිරීමට පෙර backup එකක් ගන්න.

## 5. Administrator account එකක් සෑදීම

### A. Auth user සෑදීම

1. Supabase Dashboard එකේ **Authentication → Users** වෙත යන්න.
2. **Add user → Create new user** තෝරන්න.
3. ඔබේ email address එක සහ ශක්තිමත් password එකක් යොදන්න.
4. **Auto Confirm User** option එක තිබේ නම් enable කරන්න.
5. User එක create කරන්න.
6. එම user එක open කර **User UID / ID** ලෙස දිස්වෙන UUID එක copy කරන්න. එය `123e4567-e89b-...` වැනි දිගු අගයකි.

### B. එම user එකට admin අවසර ලබා දීම

1. Supabase **SQL Editor → New Query** open කරන්න.
2. පහත SQL එකේ `PASTE-AUTH-USER-UUID` වෙනුවට copy කළ UUID එක ඇතුළත් කරන්න.

```sql
insert into public.authorized_admins (user_id)
values ('PASTE-AUTH-USER-UUID');
```

3. **Run** ඔබන්න.
4. වෙනත් account එකකට admin access ලබා දීමට අවශ්‍ය නම් එම account එකද Auth Users තුළ සාදා, එහි UUID එක සමඟ ඉහත SQL එම ලෙස run කරන්න.
5. Admin අයෙකු ඉවත් කිරීමට:

```sql
delete from public.authorized_admins
where user_id = 'REMOVE-THIS-USER-UUID';
```

**ආරක්ෂාව:** Admin password එක JavaScript file එකක හෝ වෙනත් අයෙකුට visible තැනක ලියා තබන්න එපා.

## 6. Public environment variables සකස් කිරීම

1. Supabase Dashboard එකේ **Project Settings → API Keys** වෙත යන්න.
2. **Project URL** copy කරන්න.
3. **Publishable key** copy කරන්න. ඔබේ project එකේ පැරණි key system එක භාවිත වේ නම් **anon public key** එක භාවිත කළ හැක.
4. VS Code තුළ `assets/js/config.js` open කරන්න.
5. පහත දෙක පමණක් වෙනස් කරන්න.

```js
export const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR-PUBLISHABLE-OR-ANON-KEY';
```

6. File එක save කරන්න. (`Ctrl+S` / `Cmd+S`)

**Publishable / anon key එක browser එකේ තිබීම සාමාන්‍යයි.** එය RLS policies මගින් සීමා කර ඇත. නමුත් **secret / service_role key එක කිසි විටෙක `config.js` තුළ යොදන්න එපා.**

## 7. Secure order function එක deploy කිරීම

පහසුම ක්‍රමය Supabase Dashboard එක භාවිත කිරීමයි.

### Dashboard මගින්

1. Supabase Dashboard එකේ **Edge Functions** වෙත යන්න.
2. නව function එකක් සාදා නම ලෙස හරියටම `create-order` යොදන්න.
3. VS Code තුළ `supabase/functions/create-order/index.ts` open කර සම්පූර්ණ code එක copy කරන්න.
4. Dashboard function editor එකේ code එනුවට paste කර **Deploy** ඔබන්න.
5. Function එකේ settings තුළ **Verify JWT** අවශ්‍ය දැයි අසනවා නම්, public checkout එකට එය **off / disabled** කරන්න. Project එකේ `supabase/config.toml` file එකේද මෙය සකස් කර ඇත. Order validation සහ rate limiting function එක තුළම සිදු වේ.
6. **Edge Function Secrets** වෙත ගොස් පහත secret එක add කරන්න.

```text
RATE_LIMIT_SALT = ඔබම සෑදූ දිගු අහඹු අක්ෂර පේළියක්
```

උදාහරණයක් ලෙස අක්ෂර 40කට වඩා දිගු, අන් අයට අනුමාන කළ නොහැකි text එකක් යොදන්න. මෙය customer password එකක් නොවේ.

7. Website එකේ domain එක දන්නා විට `ALLOWED_ORIGIN` secret එක ලෙස එම URL එක එක් කරන්න. උදාහරණය: `https://your-store-domain`. Domain එක වෙනස් කළ විට මෙයද යාවත්කාලීන කරන්න.

### CLI දන්නා අයට (optional)

Project root එකේ terminal එකේ:

```bash
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase secrets set RATE_LIMIT_SALT=YOUR_LONG_RANDOM_SECRET
npx supabase functions deploy create-order
```

`SUPABASE_URL` සහ server-side secret credentials Supabase Edge runtime එකෙන් ලබා දේ. ඒවා code එකට paste කරන්න එපා.

## 8. Website එක ඔබේ පරිගණකයේ run කිරීම

1. VS Code තුළ project root එකේ terminal එක open කරන්න.
2. පහත command එක run කරන්න.

```bash
npm start
```

3. Browser එකේ `http://localhost:3000` open කරන්න.
4. Customer store එක දිස්විය යුතුය.
5. Admin page එකට යාමට `http://localhost:3000/admin` භාවිත කරන්න.
6. Server එක නවත්වාමට terminal එකේ `Ctrl+C` ඔබන්න.

මෙම project එකට third-party npm packages install කිරීම අවශ්‍ය නැත. Supabase browser client එකද project එක තුළම ඇත.

## 9. Products සහ images එක් කිරීම

1. `admin.html` වෙත ගොස් සෑදූ admin email සහ password යොදා sign in කරන්න.
2. **Products → Add product** ඔබන්න.
3. Product name, SKU, category, regular price සහ stock ඇතුළත් කරන්න.
4. Discount price එකක් තිබේ නම් පමණක් එය ඇතුළත් කරන්න. එය regular price එකට වඩා අඩු විය යුතුය.
5. **Featured product** තෝරුවහොත් home page featured section එකට එය එක් වේ.
6. **Active in store** off කළහොත් product එක public catalog එකෙන් හැඳින්වේ.
7. Photo එකක් තෝරන්න. JPG, PNG හෝ WebP; උපරිමය 5 MB. පැහැදිලි, square හෝ vertical photo එකක් වඩාත් සුදුසුය.
8. **Save product** ඔබන්න.
9. Home page හෝ Shop page එක refresh කර product එක පරීක්ෂා කරන්න.
10. Sample products ඔබට අවශ්‍ය නැත්නම් Edit කර ඔබේ details යොදන්න හෝ confirm කර Delete කරන්න. පැරණි orders වල item snapshots ආරක්ෂිතව පවතී.

## 10. Logo සහ delivery fee වෙනස් කිරීම

1. Admin dashboard එකේ **Store settings** වෙත යන්න.
2. **Delivery fee (LKR)** ඇතුළත් කරන්න.
3. Logo upload කිරීමට **Store logo** යටතේ image එකක් තෝරන්න. PNG, JPG, WebP හෝ SVG; උපරිමය 5 MB.
4. **Save settings** ඔබන්න.
5. Logo එකක් නැති විට ZERONIA text logo එකම පෙනේ.
6. Delivery fee එක checkout එකේදී server එකෙන් නැවත කියවන නිසා browser එකෙන් එය වෙනස් කර order total එක වැරදි කළ නොහැක.

## 11. Cart සහ Checkout test කිරීම

Test කිරීමට සත්‍ය customer order එකක් වැනි test order එකක් සාදා පසුව admin එකෙන් Cancelled කළ හැක.

1. Shop page එකේ product එකක **Add to cart** ඔබන්න.
2. Cart icon එක open කර quantity +/− කරන්න.
3. Browser එක refresh කරන්න. Cart එක එම browser එකේ stored වී ඇති බැවින් items පවතින බව පරීක්ෂා කරන්න.
4. **Continue to checkout** ඔබන්න.
5. Required fields ඇතුළත් කර subtotal, delivery සහ final total නිවැරදි දැයි බලන්න.
6. **Place order securely** ඔබන්න.
7. Database confirm කළ පසු පමණක් “Order saved successfully” පෙනිය යුතුය.
8. WhatsApp window එකේ prepared message එක open වේ. එය **automatically send නොවේ**. ඔබ **Send** ඔබිය යුතුය.
9. Admin dashboard → Orders වෙත ගොස් order එක දිස්වෙනවාද බලන්න.
10. Order status එක Pending, Confirmed, Processing, Dispatched, Delivered අතර යාවත්කාලීන කරන්න.
11. Stock එක test order එකේ quantity එකෙන් අඩු වී ඇත්දැයි Products section එකේ බලන්න.
12. Popup blocked නම් confirmation page එකේ **Open WhatsApp order message** button එක ඔබන්න.

**Cancellation stock ආපසු automatically add නොකරයි.** Cancel කළ item නැවත විකිණීමට තිබේ නම් admin product stock එක manually යාවත්කාලීන කරන්න.

## 12. Website එක online publish කිරීම

1. Kimi preview version card එක open කර site එක desktop සහ mobile වල පරීක්ෂා කරන්න.
2. Supabase setup සහ live checkout test එක සාර්ථක බව තහවුරු කරන්න.
3. Preview තුළ **Publish** බොත්තම ඔබන්න.
4. ලැබෙන public URL එක ඔබේ customers සමඟ share කරන්න.
5. Public URL එක ලැබුණු පසු Supabase `ALLOWED_ORIGIN` secret එක එම exact origin එකට සකසන්න. Path `/...` නොයොදා scheme + domain පමණක් යොදන්න.
6. Publish කිරීමෙන් පසුත් products, prices සහ orders admin dashboard එකෙන්ම කළමනාකරණය කළ හැක.

## 13. Custom domain / subdomain පසුව සැකසීම

1. Publish කිරීමෙන් පසු platform එකේ URL settings විවෘත කර ලබා දෙන custom subdomain option එකෙන් ඔබට අවශ්‍ය නම සකසන්න.
2. ඔබට වෙනම ඔබේ domain එකක් භාවිත කිරීමට අවශ්‍ය නම්, domain provider එකේ DNS panel එක සහ hosting එකේ custom-domain instructions එකට අනුව DNS records එක් කරන්න.
3. HTTPS enable වී ඇති බව තහවුරු කරන්න.
4. නව domain එක Supabase **Authentication → URL Configuration → Site URL / Redirect URLs** තුළ යොදන්න.
5. `ALLOWED_ORIGIN` secret එකද නව domain එකට යාවත්කාලීන කරන්න.
6. Product checkout එක නව domain එකේදී නැවත test කරන්න.

## 14. ගැටලු ඇති විට

### Products පෙනෙන්නේ නැත්නම්

- `config.js` හි URL සහ key නිවැරදි ද බලන්න.
- SQL schema එක සම්පූර්ණයෙන් run වුණා ද බලන්න.
- Products **Active** ද සහ stock ඇති ද බලන්න.
- Browser DevTools → Console හි error message එක කියවන්න.

### Admin login වෙනත් account එකකට වැඩ නොකරන්නේ නම්

- Auth Users තුළ account එක සෑදී ඇත්ද බලන්න.
- `authorized_admins` table එකේ නිවැරදි UUID එක ඇත්ද බලන්න.
- Email/password නිවැරදි ද බලන්න.

### Checkout “order service not configured” කියන්නේ නම්

- `create-order` function එක deploy කර ඇත්ද බලන්න.
- Function නම හරියටම `create-order` ද බලන්න.
- Function logs බලන්න.

### WhatsApp open නොවන්නේ නම්

- Confirmation page එකේ WhatsApp button එක භාවිත කරන්න.
- Browser popup blocker එකේ ඔබේ site එකට popups allow කරන්න.
- WhatsApp තුළ message එක send වූයේ ඔබ Send ඔබූ පසු පමණි.

## 15. ආරක්ෂිත භාවිතයට වැදගත් දේ

- Secret / service_role key frontend එකට කිසිදා එක් නොකරන්න.
- `.env` files public repository එකකට upload නොකරන්න.
- Admin account වල ශක්තිමත්, වෙනම passwords භාවිත කරන්න.
- Customer orders සහ phone numbers public shares නොකරන්න.
- Database backups සහ Supabase security advisories නිතර පරීක්ෂා කරන්න.
- Card payments තවම integrate කර නැත. Cash on Delivery පමණක් enabled ය. Card details එකතු කරන form එකක් එක් නොකරන්න.
