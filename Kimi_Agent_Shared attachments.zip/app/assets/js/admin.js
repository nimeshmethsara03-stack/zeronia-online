import { getSupabase, isConfigured } from './supabase.js';
import { qs, qsa, money, escapeHTML, errorMessage, toast } from './utils.js';

const statuses = ['Pending', 'Confirmed', 'Processing', 'Dispatched', 'Delivered', 'Cancelled'];
let products = [], categories = [], orders = [], settings = null, user = null;
const productSelect = '*, categories(name, slug)';
const message = (text, type = 'error') => { qs('#admin-message').innerHTML = `<div class="${type}-box">${escapeHTML(text)}</div>`; setTimeout(() => qs('#admin-message').innerHTML = '', 5000); };
const showLogin = (text = '') => { qs('#admin-login').hidden = false; qs('#admin-shell').hidden = true; if (text) qs('#login-message').innerHTML = `<div class="error-box">${escapeHTML(text)}</div>`; };
const openDialog = id => qs(`#${id}`).showModal();
const closeDialog = id => qs(`#${id}`).close();
qsa('[data-close]').forEach(button => button.addEventListener('click', () => closeDialog(button.dataset.close)));
qsa('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); }));

if (!isConfigured) showLogin('Supabase is not configured. Add your public project URL and anon key in assets/js/config.js first.');
else {
  const supabase = getSupabase();
  const { data: { session } } = await supabase.auth.getSession();
  if (session) await authorize(session.user); else showLogin();
  qs('#login-form').addEventListener('submit', async event => {
    event.preventDefault(); const button = qs('#login-button'); button.disabled = true; button.textContent = 'Signing in…'; qs('#login-message').innerHTML = '';
    const { error } = await supabase.auth.signInWithPassword({ email: qs('#admin-email').value.trim(), password: qs('#admin-password').value });
    if (error) { showLogin(error.message); button.disabled = false; button.textContent = 'Sign in securely'; }
    else { const { data } = await supabase.auth.getSession(); await authorize(data.session.user); button.disabled = false; button.textContent = 'Sign in securely'; }
  });
  qs('#logout-button').addEventListener('click', async () => { await supabase.auth.signOut(); location.reload(); });
}

async function authorize(account) {
  const { data, error } = await getSupabase().from('authorized_admins').select('user_id').eq('user_id', account.id).maybeSingle();
  if (error || !data) { await getSupabase().auth.signOut(); showLogin('This account is not on the authorized administrator list.'); return; }
  user = account; qs('#admin-login').hidden = true; qs('#admin-shell').hidden = false; qs('#admin-user').textContent = account.email;
  await loadAll(); bindAdmin();
}

async function loadAll() {
  try {
    const supabase = getSupabase();
    const [p, c, o, s] = await Promise.all([
      supabase.from('products').select(productSelect).order('created_at', { ascending: false }),
      supabase.from('categories').select('*').order('name'),
      supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false }),
      supabase.from('store_settings').select('*').eq('id', 1).single(),
    ]);
    const failure = [p, c, o, s].find(result => result.error); if (failure) throw failure.error;
    products = p.data || []; categories = c.data || []; orders = o.data || []; settings = s.data;
    renderAll();
  } catch (error) { message(errorMessage(error)); }
}

function renderAll() { renderStats(); renderProducts(); renderCategories(); renderOrders(); renderSettings(); }
function renderStats() {
  const valid = orders.filter(order => order.status !== 'Cancelled'); const revenue = valid.reduce((sum, order) => sum + Number(order.total), 0);
  qs('#stats-grid').innerHTML = [['Sales value', money(revenue)], ['Total orders', orders.length], ['Pending orders', orders.filter(order => order.status === 'Pending').length], ['Active products', products.filter(product => product.is_active).length]].map(([label, value]) => `<div class="stat"><span>${label}</span><strong>${value}</strong></div>`).join('');
  qs('#recent-orders').innerHTML = ordersTable(orders.slice(0, 5), true); bindOrderButtons();
}
function renderProducts() {
  const q = qs('#product-search').value.trim().toLowerCase(); const category = qs('#admin-product-category').value;
  const list = products.filter(product => (!q || `${product.name} ${product.sku}`.toLowerCase().includes(q)) && (!category || product.category_id === category));
  qs('#admin-product-category').innerHTML = '<option value="">All categories</option>' + categories.map(row => `<option value="${row.id}" ${row.id === category ? 'selected' : ''}>${escapeHTML(row.name)}</option>`).join('');
  qs('#product-category').innerHTML = categories.map(row => `<option value="${row.id}">${escapeHTML(row.name)}${row.is_active ? '' : ' (inactive)'}</option>`).join('');
  qs('#products-table').innerHTML = list.length ? `<table><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody>${list.map(product => `<tr><td><strong>${escapeHTML(product.name)}</strong><br><span class="muted">${escapeHTML(product.sku)}</span></td><td>${escapeHTML(product.categories?.name || '—')}</td><td>${money(product.discount_price ?? product.regular_price)}${product.discount_price ? `<br><del class="muted">${money(product.regular_price)}</del>` : ''}</td><td>${product.stock_quantity}</td><td><span class="status status-${product.is_active ? 'active' : 'inactive'}">${product.is_active ? 'Active' : 'Inactive'}</span>${product.is_featured ? '<br><span class="small">Featured</span>' : ''}</td><td><div class="table-actions"><button class="btn btn-outline btn-sm" data-edit-product="${product.id}">Edit</button><button class="btn btn-danger btn-sm" data-delete-product="${product.id}">Delete</button></div></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No products match this view.</p>';
  qsa('[data-edit-product]').forEach(button => button.addEventListener('click', () => editProduct(button.dataset.editProduct)));
  qsa('[data-delete-product]').forEach(button => button.addEventListener('click', () => deleteProduct(button.dataset.deleteProduct)));
}
function renderCategories() {
  qs('#categories-table').innerHTML = `<table><thead><tr><th>Name</th><th>Slug</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead><tbody>${categories.map(category => `<tr><td><strong>${escapeHTML(category.name)}</strong></td><td>${escapeHTML(category.slug)}</td><td>${products.filter(product => product.category_id === category.id).length}</td><td><span class="status status-${category.is_active ? 'active' : 'inactive'}">${category.is_active ? 'Active' : 'Inactive'}</span></td><td><div class="table-actions"><button class="btn btn-outline btn-sm" data-edit-category="${category.id}">Edit</button><button class="btn btn-danger btn-sm" data-delete-category="${category.id}">Delete</button></div></td></tr>`).join('')}</tbody></table>`;
  qsa('[data-edit-category]').forEach(button => button.addEventListener('click', () => editCategory(button.dataset.editCategory)));
  qsa('[data-delete-category]').forEach(button => button.addEventListener('click', () => deleteCategory(button.dataset.deleteCategory)));
}
function ordersTable(list, compact = false) {
  return list.length ? `<table><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th></th></tr></thead><tbody>${list.map(order => `<tr><td><strong>${escapeHTML(order.order_number)}</strong></td><td>${escapeHTML(order.customer_name)}<br><span class="muted">${escapeHTML(order.mobile_number)}</span></td><td>${money(order.total)}</td><td><span class="status status-${order.status.toLowerCase()}">${order.status}</span></td><td>${new Date(order.created_at).toLocaleDateString('en-LK')}</td><td><button class="btn btn-outline btn-sm" data-view-order="${order.id}">${compact ? 'View' : 'View / update'}</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No orders match this view.</p>';
}
function renderOrders() {
  const q = qs('#order-search').value.trim().toLowerCase(); const status = qs('#order-status-filter').value;
  const list = orders.filter(order => (!q || `${order.order_number} ${order.customer_name} ${order.mobile_number}`.toLowerCase().includes(q)) && (!status || order.status === status));
  qs('#orders-table').innerHTML = ordersTable(list); bindOrderButtons();
}
function bindOrderButtons() { qsa('[data-view-order]').forEach(button => button.addEventListener('click', () => viewOrder(button.dataset.viewOrder))); }
function renderSettings() { qs('#delivery-fee-setting').value = Number(settings.delivery_fee); qs('#current-logo').innerHTML = settings.logo_url ? `<img class="image-preview" src="${escapeHTML(settings.logo_url)}" alt="Current store logo">` : '<p class="small muted">The ZERONIA text logo is currently in use.</p>'; }

function editProduct(id) {
  const product = products.find(row => row.id === id); if (!product) return;
  qs('#product-dialog-title').textContent = 'Edit product'; qs('#product-id').value = product.id; qs('#product-name').value = product.name; qs('#product-sku').value = product.sku; qs('#product-category').value = product.category_id; qs('#product-description').value = product.description || ''; qs('#regular-price').value = product.regular_price; qs('#discount-price').value = product.discount_price ?? ''; qs('#stock-quantity').value = product.stock_quantity; qs('#product-active').checked = product.is_active; qs('#product-featured').checked = product.is_featured; qs('#existing-image').value = product.image_url || ''; qs('#product-image').value = ''; qs('#product-image-preview').innerHTML = product.image_url ? `<img class="image-preview" src="${escapeHTML(product.image_url)}" alt="Current product">` : ''; openDialog('product-dialog');
}
async function deleteProduct(id) {
  const product = products.find(row => row.id === id); if (!confirm(`Delete “${product.name}”? Past orders will retain their product snapshots.`)) return;
  const { error } = await getSupabase().from('products').delete().eq('id', id); if (error) message(error.message); else { toast('Product deleted.'); await loadAll(); }
}
function editCategory(id) {
  const category = categories.find(row => row.id === id); qs('#category-dialog-title').textContent = id ? 'Edit category' : 'Add category'; qs('#category-id').value = id || ''; qs('#category-name').value = category?.name || ''; qs('#category-active').checked = category?.is_active ?? true; openDialog('category-dialog');
}
async function deleteCategory(id) {
  const category = categories.find(row => row.id === id); const count = products.filter(product => product.category_id === id).length;
  if (count) { message(`Move or delete ${count} products in this category first.`); return; }
  if (!confirm(`Delete category “${category.name}”?`)) return;
  const { error } = await getSupabase().from('categories').delete().eq('id', id); if (error) message(error.message); else { toast('Category deleted.'); await loadAll(); }
}
function viewOrder(id) {
  const order = orders.find(row => row.id === id); if (!order) return; qs('#order-dialog-title').textContent = order.order_number;
  qs('#order-detail').innerHTML = `<div class="order-detail-grid"><div><h3>Customer</h3><p><strong>${escapeHTML(order.customer_name)}</strong><br>${escapeHTML(order.mobile_number)}${order.whatsapp_number ? `<br>WhatsApp: ${escapeHTML(order.whatsapp_number)}` : ''}</p><h3>Delivery</h3><p>${escapeHTML(order.delivery_address)}<br>${escapeHTML(order.city)}</p>${order.delivery_instructions ? `<p><strong>Instructions:</strong><br>${escapeHTML(order.delivery_instructions)}</p>` : ''}${order.gift_message ? `<p><strong>Gift message:</strong><br>${escapeHTML(order.gift_message)}</p>` : ''}</div><div><h3>Order status</h3><div class="field"><select id="update-order-status">${statuses.map(status => `<option ${status === order.status ? 'selected' : ''}>${status}</option>`).join('')}</select></div><button class="btn btn-primary btn-sm" id="save-order-status" style="margin-top:12px">Update status</button><p class="small muted">Placed ${new Date(order.created_at).toLocaleString('en-LK')}</p></div></div><h3>Items</h3>${order.order_items.map(item => `<div class="summary-row"><span>${escapeHTML(item.product_name)}<br><span class="muted">${escapeHTML(item.product_sku)} × ${item.quantity}</span></span><strong>${money(item.line_total)}</strong></div>`).join('')}<div class="summary-row"><span>Subtotal</span><strong>${money(order.subtotal)}</strong></div><div class="summary-row"><span>Delivery</span><strong>${money(order.delivery_fee)}</strong></div><div class="summary-row summary-total"><span>Total</span><span>${money(order.total)}</span></div>`;
  qs('#save-order-status').addEventListener('click', async () => { const { error } = await getSupabase().from('orders').update({ status: qs('#update-order-status').value }).eq('id', id); if (error) message(error.message); else { toast('Order status updated.'); closeDialog('order-dialog'); await loadAll(); } }); openDialog('order-dialog');
}

async function uploadImage(bucket, path, file) {
  if (!file) return null; if (!['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'].includes(file.type) || file.size > 5 * 1024 * 1024) throw new Error('Choose a JPG, PNG, WebP or SVG image smaller than 5 MB.');
  const extension = file.name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, ''); const safePath = `${path}-${Date.now()}.${extension}`;
  const { error } = await getSupabase().storage.from(bucket).upload(safePath, file, { cacheControl: '3600', upsert: false }); if (error) throw error;
  return getSupabase().storage.from(bucket).getPublicUrl(safePath).data.publicUrl;
}
function bindAdmin() {
  qsa('[data-panel]').forEach(button => button.addEventListener('click', () => { qsa('[data-panel]').forEach(row => row.classList.toggle('active', row === button)); qsa('.admin-panel').forEach(panel => panel.classList.toggle('active', panel.id === `panel-${button.dataset.panel}`)); qs('#admin-title').textContent = button.textContent; qs('#admin-sidebar').classList.remove('open'); }));
  qs('[data-go-orders]').addEventListener('click', () => qs('[data-panel="orders"]').click()); qs('#admin-menu').addEventListener('click', () => qs('#admin-sidebar').classList.toggle('open'));
  qs('#product-search').addEventListener('input', renderProducts); qs('#admin-product-category').addEventListener('change', renderProducts); qs('#order-search').addEventListener('input', renderOrders); qs('#order-status-filter').addEventListener('change', renderOrders);
  qs('#add-product').addEventListener('click', () => { if (!categories.length) { message('Add a category first.'); return; } qs('#product-form').reset(); qs('#product-id').value = ''; qs('#existing-image').value = ''; qs('#product-image-preview').innerHTML = ''; qs('#product-active').checked = true; qs('#product-dialog-title').textContent = 'Add product'; openDialog('product-dialog'); });
  qs('#add-category').addEventListener('click', () => editCategory(''));
  qs('#product-form').addEventListener('submit', async event => {
    event.preventDefault(); const button = qs('#save-product'); button.disabled = true;
    try {
      const id = qs('#product-id').value; const regular = Number(qs('#regular-price').value); const discount = qs('#discount-price').value === '' ? null : Number(qs('#discount-price').value);
      if (discount !== null && discount >= regular) throw new Error('Discounted price must be lower than the regular price.');
      let imageUrl = qs('#existing-image').value || null; const uploaded = await uploadImage('product-images', crypto.randomUUID(), qs('#product-image').files[0]); if (uploaded) imageUrl = uploaded;
      const record = { name: qs('#product-name').value.trim(), sku: qs('#product-sku').value.trim().toUpperCase(), category_id: qs('#product-category').value, description: qs('#product-description').value.trim(), regular_price: regular, discount_price: discount, stock_quantity: Number(qs('#stock-quantity').value), is_active: qs('#product-active').checked, is_featured: qs('#product-featured').checked, image_url: imageUrl };
      const { error } = id ? await getSupabase().from('products').update(record).eq('id', id) : await getSupabase().from('products').insert(record); if (error) throw error;
      closeDialog('product-dialog'); toast('Product saved.'); await loadAll();
    } catch (error) { message(errorMessage(error)); } finally { button.disabled = false; }
  });
  qs('#category-form').addEventListener('submit', async event => {
    event.preventDefault(); const id = qs('#category-id').value; const name = qs('#category-name').value.trim(); const slug = name.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const { error } = id ? await getSupabase().from('categories').update({ name, slug, is_active: qs('#category-active').checked }).eq('id', id) : await getSupabase().from('categories').insert({ name, slug, is_active: qs('#category-active').checked });
    if (error) message(error.message); else { closeDialog('category-dialog'); toast('Category saved.'); await loadAll(); }
  });
  qs('#settings-form').addEventListener('submit', async event => {
    event.preventDefault(); const button = qs('#save-settings'); button.disabled = true;
    try { const uploaded = await uploadImage('site-assets', 'store-logo', qs('#logo-file').files[0]); const record = { delivery_fee: Number(qs('#delivery-fee-setting').value) }; if (uploaded) record.logo_url = uploaded; const { error } = await getSupabase().from('store_settings').update(record).eq('id', 1); if (error) throw error; toast('Store settings saved.'); await loadAll(); } catch (error) { message(errorMessage(error)); } finally { button.disabled = false; }
  });
}
