import { safeJSON } from './utils.js';
const KEY = 'zeronia_cart_v1';
export const getCart = () => {
  const cart = safeJSON(localStorage.getItem(KEY), []);
  return Array.isArray(cart) ? cart.filter(item => typeof item.id === 'string' && Number.isInteger(item.qty) && item.qty > 0 && item.qty <= 99) : [];
};
const save = cart => { localStorage.setItem(KEY, JSON.stringify(cart)); window.dispatchEvent(new CustomEvent('zeronia:cart')); };
export const addToCart = (id, qty = 1) => {
  const cart = getCart(); const existing = cart.find(item => item.id === id);
  const amount = Math.max(1, Math.min(99, Number(qty) || 1));
  if (existing) existing.qty = Math.min(99, existing.qty + amount); else cart.push({ id, qty: amount });
  save(cart);
};
export const setQuantity = (id, qty) => { const cart = getCart(); const item = cart.find(row => row.id === id); if (!item) return; item.qty = Math.max(1, Math.min(99, Number(qty) || 1)); save(cart); };
export const removeFromCart = id => save(getCart().filter(item => item.id !== id));
export const clearCart = () => save([]);
export const cartCount = () => getCart().reduce((sum, item) => sum + item.qty, 0);
