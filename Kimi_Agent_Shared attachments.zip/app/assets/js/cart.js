import { initLayout } from './components.js';
import { isConfigured } from './supabase.js';
import { fetchProductsByIds, fetchSettings } from './db.js';
import { getCart, setQuantity, removeFromCart } from './cart-store.js';
import { qs, money, escapeHTML, imageHTML, setupNotice, emptyHTML, errorMessage } from './ui-helpers.js';
await initLayout();
async function renderCart() {
  const target = qs('#cart-content'); const cart = getCart();
  if (!cart.length) { target.innerHTML = emptyHTML('Your cart is waiting for something special', 'Browse the collection and add a gift you love.', '<a class="btn btn-primary" href="catalog.html">Explore gifts</a>'); return; }
  if (!isConfigured) { qs('#configuration-notice').innerHTML = setupNotice(); target.innerHTML = emptyHTML('Connect your store to review this cart', 'Product prices and stock must come from Supabase.'); return; }
  try {
    const [products, settings] = await Promise.all([fetchProductsByIds(cart.map(item => item.id)), fetchSettings()]);
    const rows = cart.map(item => ({ ...item, product: products.find(product => product.id === item.id) })).filter(item => item.product);
    if (!rows.length) { target.innerHTML = emptyHTML('These products are no longer available', 'Return to the shop to find another gift.', '<a class="btn btn-primary" href="catalog.html">Back to shop</a>'); return; }
    const subtotal = rows.reduce((sum, item) => sum + Number(item.product.discount_price ?? item.product.regular_price) * item.qty, 0);
    const delivery = Number(settings.delivery_fee);
    target.innerHTML = `<div class="cart-layout"><div class="cart-list">${rows.map(item => {
      const product = item.product; const stock = Number(product.stock_quantity); const unavailable = !product.is_active || stock < item.qty;
      return `<article class="cart-item"><a class="cart-thumb" href="product.html?id=${product.id}">${imageHTML(product)}</a><div><h3><a href="product.html?id=${product.id}">${escapeHTML(product.name)}</a></h3><span class="small muted">${escapeHTML(product.sku)} · ${money(product.discount_price ?? product.regular_price)}</span>${unavailable ? '<p class="small stock-low">Please adjust quantity — current stock is unavailable or insufficient.</p>' : ''}<div class="cart-item-actions"><div class="qty-control"><button data-qty-minus="${item.id}" aria-label="Decrease ${escapeHTML(product.name)} quantity">−</button><input data-qty="${item.id}" type="number" min="1" max="99" value="${item.qty}" aria-label="${escapeHTML(product.name)} quantity"><button data-qty-plus="${item.id}" aria-label="Increase ${escapeHTML(product.name)} quantity">+</button></div><button class="remove-btn" data-remove="${item.id}">Remove</button></div></div><div class="cart-item-total">${money(Number(product.discount_price ?? product.regular_price) * item.qty)}</div></article>`;
    }).join('')}</div><aside class="summary"><h2>Order summary</h2><div class="summary-row"><span>Subtotal</span><strong>${money(subtotal)}</strong></div><div class="summary-row"><span>Delivery</span><strong>${money(delivery)}</strong></div><div class="summary-row summary-total"><span>Total</span><span>${money(subtotal + delivery)}</span></div><a class="btn btn-primary btn-block" href="checkout.html">Continue to checkout</a><p class="small muted">Stock and final totals are verified again at checkout.</p><div class="payment-note">Cash on Delivery available. No online card payment is collected.</div></aside></div>`;
    rows.forEach(item => {
      qs(`[data-qty-minus="${item.id}"]`).addEventListener('click', () => { setQuantity(item.id, item.qty - 1); renderCart(); });
      qs(`[data-qty-plus="${item.id}"]`).addEventListener('click', () => { setQuantity(item.id, item.qty + 1); renderCart(); });
      qs(`[data-qty="${item.id}"]`).addEventListener('change', event => { setQuantity(item.id, event.target.value); renderCart(); });
      qs(`[data-remove="${item.id}"]`).addEventListener('click', () => { removeFromCart(item.id); renderCart(); });
    });
  } catch (error) { target.innerHTML = `<div class="error-box">${errorMessage(error)}</div>`; }
}
await renderCart();
