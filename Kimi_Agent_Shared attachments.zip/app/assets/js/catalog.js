import { initLayout } from './components.js';
import { isConfigured } from './supabase.js';
import { fetchCategories, fetchProducts } from './db.js';
import { qs, escapeHTML, productCard, setupNotice, emptyHTML, errorMessage } from './ui-helpers.js';
await initLayout();
const params = new URLSearchParams(location.search);
let products = [];
function render() {
  const q = qs('#catalog-search').value.trim().toLowerCase(); const category = qs('#category-filter').value; const sort = qs('#sort-filter').value;
  let list = products.filter(product => (!q || `${product.name} ${product.sku} ${product.description}`.toLowerCase().includes(q)) && (!category || product.categories?.slug === category));
  if (params.get('featured') === 'true') list = list.filter(product => product.is_featured);
  const price = product => Number(product.discount_price ?? product.regular_price);
  list.sort((a, b) => sort === 'price-asc' ? price(a) - price(b) : sort === 'price-desc' ? price(b) - price(a) : sort === 'name' ? a.name.localeCompare(b.name) : new Date(b.created_at) - new Date(a.created_at));
  qs('#results-meta').textContent = `${list.length} ${list.length === 1 ? 'product' : 'products'} found`;
  qs('#catalog-products').innerHTML = list.length ? list.map(productCard).join('') : emptyHTML('No products found', 'Try a different search or category.', '<button class="btn btn-outline" id="clear-filters">Clear filters</button>');
  qs('#clear-filters')?.addEventListener('click', () => { qs('#catalog-search').value = ''; qs('#category-filter').value = ''; params.delete('featured'); render(); });
}
if (!isConfigured) {
  qs('#configuration-notice').innerHTML = setupNotice(); qs('#catalog-products').innerHTML = emptyHTML('Catalog not connected', 'Connect Supabase to load your live products.'); qs('#results-meta').textContent = '';
  ['#catalog-search', '#category-filter', '#sort-filter'].forEach(id => qs(id).disabled = true);
} else {
  try {
    const [categories, rows] = await Promise.all([fetchCategories(), fetchProducts()]); products = rows;
    qs('#category-filter').innerHTML += categories.map(category => `<option value="${escapeHTML(category.slug)}">${escapeHTML(category.name)}</option>`).join('');
    qs('#catalog-search').value = params.get('q') || ''; qs('#category-filter').value = params.get('category') || ''; qs('#sort-filter').value = params.get('sort') || 'newest';
    ['#catalog-search', '#category-filter', '#sort-filter'].forEach(id => qs(id).addEventListener(id === '#catalog-search' ? 'input' : 'change', render)); render();
  } catch (error) { qs('#configuration-notice').innerHTML = `<div class="error-box">${errorMessage(error)}</div>`; qs('#catalog-products').innerHTML = emptyHTML('Could not load products', 'Please refresh and try again.'); }
}
