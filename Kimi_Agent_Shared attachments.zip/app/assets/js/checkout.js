import { initLayout } from './components.js';
import { isConfigured, getSupabase } from './supabase.js';
import { fetchProductsByIds, fetchSettings } from './db.js';
import { getCart, clearCart } from './cart-store.js';
import { whatsappOrderURL } from './order-message.js';
import { qs, money, escapeHTML, imageHTML, setupNotice, emptyHTML, errorMessage } from './ui-helpers.js';
await initLayout();
const target = qs('#checkout-content');
async function initCheckout() {
  const cart = getCart();
  if (!cart.length) { target.innerHTML = emptyHTML('Your cart is empty', 'Add a gift before starting checkout.', '<a class="btn btn-primary" href="catalog.html">Browse gifts</a>'); return; }
  if (!isConfigured) { qs('#configuration-notice').innerHTML = setupNotice(); target.innerHTML = emptyHTML('Checkout is not connected', 'Complete the Supabase setup before accepting customer orders.'); return; }
  try {
    const [products, settings] = await Promise.all([fetchProductsByIds(cart.map(item => item.id)), fetchSettings()]);
    const rows = cart.map(item => ({ ...item, product: products.find(product => product.id === item.id) }));
    if (rows.some(item => !item.product || !item.product.is_active || item.product.stock_quantity < item.qty)) { target.innerHTML = emptyHTML('Your cart needs attention', 'A product is unavailable or has insufficient stock. Please return to your cart and adjust it.', '<a class="btn btn-primary" href="cart.html">Review cart</a>'); return; }
    const subtotal = rows.reduce((sum, item) => sum + Number(item.product.discount_price ?? item.product.regular_price) * item.qty, 0); const delivery = Number(settings.delivery_fee);
    target.innerHTML = `<form class="checkout-layout" id="checkout-form"><div><h2>Delivery details</h2><p class="muted">Fields marked * are required.</p><div class="form-grid">
      <div class="field full"><label for="customer_name">Full name *</label><input id="customer_name" name="customer_name" autocomplete="name" maxlength="120" required></div>
      <div class="field"><label for="mobile_number">Mobile number *</label><input id="mobile_number" name="mobile_number" type="tel" autocomplete="tel" placeholder="07X XXX XXXX" maxlength="20" required></div>
      <div class="field"><label for="whatsapp_number">WhatsApp number (optional)</label><input id="whatsapp_number" name="whatsapp_number" type="tel" autocomplete="tel" maxlength="20"></div>
      <div class="field full"><label for="delivery_address">Full delivery address *</label><textarea id="delivery_address" name="delivery_address" autocomplete="street-address" maxlength="500" required></textarea></div>
      <div class="field full"><label for="city">City / town *</label><input id="city" name="city" autocomplete="address-level2" maxlength="120" required></div>
      <div class="field full"><label for="delivery_instructions">Delivery instructions</label><textarea id="delivery_instructions" name="delivery_instructions" maxlength="500" placeholder="Landmark, preferred time, or other helpful details"></textarea></div>
      <div class="field full"><label for="gift_message">Gift message (optional)</label><textarea id="gift_message" name="gift_message" maxlength="500" placeholder="A note to include with your gift"></textarea></div>
      <div class="full"><label class="checkbox"><input type="checkbox" required> I confirm my delivery details and Cash on Delivery order.</label></div>
      </div><div id="checkout-error" aria-live="polite"></div></div><aside class="summary"><h2>Your order</h2>${rows.map(item => `<div class="order-mini"><div>${imageHTML(item.product)}</div><span>${escapeHTML(item.product.name)}<br><span class="muted">Qty ${item.qty}</span></span><strong>${money(Number(item.product.discount_price ?? item.product.regular_price) * item.qty)}</strong></div>`).join('')}<div class="summary-row"><span>Subtotal</span><strong>${money(subtotal)}</strong></div><div class="summary-row"><span>Delivery</span><strong>${money(delivery)}</strong></div><div class="summary-row summary-total"><span>Final total</span><span>${money(subtotal + delivery)}</span></div><div class="payment-note"><strong>Cash on Delivery</strong><br>Pay when your order arrives. No card details are requested.</div><button class="btn btn-primary btn-block" id="place-order" type="submit">Place order securely</button><p class="small muted">The server verifies product prices, stock and delivery charges before saving. After confirmation, WhatsApp opens with your order ready for you to press Send.</p></aside></form>`;
    const form = qs('#checkout-form'); const idempotencyKey = crypto.randomUUID();
    form.addEventListener('submit', async event => {
      event.preventDefault(); if (!form.reportValidity()) return;
      const button = qs('#place-order'); button.disabled = true; button.textContent = 'Verifying & saving…'; qs('#checkout-error').innerHTML = '';
      const data = new FormData(form); const customer = Object.fromEntries(data.entries());
      try {
        const { data: result, error } = await getSupabase().functions.invoke('create-order', { body: { customer, items: cart, idempotency_key: idempotencyKey } });
        if (error) { let detail = error.message || 'The order could not be saved.'; try { const body = await error.context?.json(); if (body?.error) detail = body.error; } catch { /* Keep the function error message. */ } throw new Error(detail); }
        if (!result?.order?.order_number) throw new Error(result?.error || 'The database did not confirm your order. Please try again.');
        const order = result.order; const items = result.items || [];
        sessionStorage.setItem('zeronia_last_order', JSON.stringify({ order, items }));
        const url = whatsappOrderURL(order, items); const whatsappWindow = window.open(url, '_blank', 'noopener');
        clearCart(); location.href = `confirmation.html?order=${encodeURIComponent(order.order_number)}${whatsappWindow ? '' : '&whatsapp=blocked'}`;
      } catch (error) { qs('#checkout-error').innerHTML = `<div class="error-box">${escapeHTML(errorMessage(error))}<br>Your cart is still saved. No success has been assumed.</div>`; button.disabled = false; button.textContent = 'Place order securely'; }
    });
  } catch (error) { target.innerHTML = `<div class="error-box">${errorMessage(error)}</div>`; }
}
await initCheckout();
