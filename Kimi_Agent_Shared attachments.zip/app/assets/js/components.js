import { icon, qs, qsa, escapeHTML, toast, placeholder } from './utils.js';
import { WHATSAPP_NUMBER } from './config.js';
import { isConfigured } from './supabase.js';
import { fetchSettings } from './db.js';
import { addToCart, cartCount } from './cart-store.js';

const page = document.body.dataset.page || '';
const active = key => page === key ? 'active' : '';
const whatsappURL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Hello ZERONIA, I would like to ask about a gift.')}`;

export async function initLayout() {
  const header = qs('#site-header');
  if (header) header.innerHTML = `<div class="announcement">Islandwide delivery · Cash on Delivery · Thoughtfully chosen in Nawalapitiya</div>
    <div class="site-header"><div class="container header-main">
      <a class="brand" href="index.html" aria-label="ZERONIA home" id="brand-area"><span class="brand-name">ZERONIA</span><span class="brand-tag">Special Gifts · Beautiful Moments</span></a>
      <nav class="main-nav" id="main-nav" aria-label="Main navigation"><a class="${active('home')}" href="index.html">Home</a><a class="${active('catalog')}" href="catalog.html">Shop</a><a class="${active('about')}" href="about.html">Our story</a><a class="${active('contact')}" href="contact.html">Contact</a></nav>
      <div class="header-actions"><button class="icon-btn search-toggle" aria-label="Toggle search" aria-expanded="false">${icon('search')}</button><a class="icon-btn" href="cart.html" aria-label="Shopping cart">${icon('bag')}<span class="cart-count" id="cart-count">0</span></a><button class="icon-btn menu-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="main-nav">${icon('menu')}</button></div>
    </div><div class="container header-search" hidden><form class="search-form" action="catalog.html" method="get"><label class="sr-only" for="site-search">Search products</label><input id="site-search" name="q" type="search" placeholder="Search gifts, bouquets, accessories…" required><button class="icon-btn" type="submit" aria-label="Search">${icon('search')}</button></form></div></div>`;
  const footer = qs('#site-footer');
  if (footer) footer.innerHTML = `<footer class="site-footer"><div class="container"><div class="footer-grid">
    <div class="footer-brand"><a class="brand" href="index.html"><span class="brand-name">ZERONIA</span><span class="brand-tag">Special Gifts · Beautiful Moments</span></a><p>Meaningful gifts and beautiful finishing touches, selected with care in Nawalapitiya, Sri Lanka.</p></div>
    <div><h3>Explore</h3><a href="catalog.html">All products</a><a href="catalog.html?sort=newest">New arrivals</a><a href="catalog.html?featured=true">Featured gifts</a><a href="about.html">Our story</a></div>
    <div><h3>Customer care</h3><a href="contact.html">Contact us</a><a href="cart.html">Your cart</a><a href="checkout.html">Checkout</a><a href="admin.html">Store administration</a></div>
    <div><h3>Find us</h3><p class="small">Nawalapitiya<br>Sri Lanka</p><a href="https://wa.me/${WHATSAPP_NUMBER}" target="_blank" rel="noopener">WhatsApp +94 70 344 4266</a><p class="small">Cash on Delivery available</p></div>
  </div><div class="footer-bottom"><span>© ${new Date().getFullYear()} ZERONIA Gift & Accessories</span><span>Special Gifts · Beautiful Moments</span></div></div></footer><a class="whatsapp-float" href="${whatsappURL}" target="_blank" rel="noopener" aria-label="Chat with ZERONIA on WhatsApp">${icon('whatsapp')}</a>`;
  const updateCount = () => qsa('#cart-count').forEach(el => el.textContent = cartCount());
  updateCount(); window.addEventListener('zeronia:cart', updateCount);
  qs('.menu-toggle')?.addEventListener('click', event => { const open = qs('#main-nav').classList.toggle('open'); event.currentTarget.setAttribute('aria-expanded', open); });
  qs('.search-toggle')?.addEventListener('click', event => { const bar = qs('.header-search'); bar.hidden = !bar.hidden; event.currentTarget.setAttribute('aria-expanded', !bar.hidden); if (!bar.hidden) qs('#site-search').focus(); });
  window.addEventListener('scroll', () => qs('.site-header')?.classList.toggle('scrolled', scrollY > 10), { passive: true });
  document.addEventListener('click', event => {
    const add = event.target.closest('[data-add-cart]'); const buy = event.target.closest('[data-buy-now]');
    if (add) { addToCart(add.dataset.addCart, add.dataset.qty || 1); toast('Added to your cart.'); }
    if (buy) { addToCart(buy.dataset.buyNow, buy.dataset.qty || 1); location.href = 'checkout.html'; }
  });
  document.addEventListener('error', event => { if (event.target instanceof HTMLImageElement) { const wrap = document.createElement('div'); wrap.innerHTML = placeholder(); event.target.replaceWith(wrap.firstElementChild); } }, true);
  if (isConfigured) {
    try { const settings = await fetchSettings(); if (settings.logo_url) qs('#brand-area').innerHTML = `<img class="brand-logo" src="${escapeHTML(settings.logo_url)}" alt="ZERONIA Gift & Accessories">`; } catch { /* Brand fallback remains visible. */ }
  }
  const heroImage = qs('.hero-visual img');
  if (heroImage && !matchMedia('(prefers-reduced-motion: reduce)').matches) window.addEventListener('scroll', () => { const y = Math.min(8, scrollY / 90); heroImage.style.setProperty('--parallax', `${-4 + y}%`); }, { passive: true });
}
