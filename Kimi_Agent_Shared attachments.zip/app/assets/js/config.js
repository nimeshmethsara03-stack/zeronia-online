// Public browser configuration only. Never put a service-role key here.
// Replace these two values after creating your Supabase project.
export const SUPABASE_URL = 'YOUR_SUPABASE_URL';
export const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
export const WHATSAPP_NUMBER = '94703444266';
export const BUSINESS_NAME = 'ZERONIA Gift & Accessories';
