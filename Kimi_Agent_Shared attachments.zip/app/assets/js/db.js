import { getSupabase } from './supabase.js';
const productSelect = '*, categories(name, slug)';
export async function fetchSettings() {
  const { data, error } = await getSupabase().from('store_settings').select('delivery_fee, logo_url').eq('id', 1).single();
  if (error) throw error; return data;
}
export async function fetchCategories() {
  const { data, error } = await getSupabase().from('categories').select('*').eq('is_active', true).order('name');
  if (error) throw error; return data || [];
}
export async function fetchProducts(activeOnly = true) {
  let query = getSupabase().from('products').select(productSelect).order('created_at', { ascending: false });
  if (activeOnly) query = query.eq('is_active', true);
  const { data, error } = await query; if (error) throw error; return data || [];
}
export async function fetchProduct(id) {
  const { data, error } = await getSupabase().from('products').select(productSelect).eq('id', id).eq('is_active', true).maybeSingle();
  if (error) throw error; return data;
}
export async function fetchProductsByIds(ids) {
  if (!ids.length) return [];
  const { data, error } = await getSupabase().from('products').select(productSelect).in('id', ids);
  if (error) throw error; return data || [];
}
