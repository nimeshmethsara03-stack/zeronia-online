import { initLayout } from './components.js';
import { isConfigured } from './supabase.js';
import { fetchCategories, fetchProducts } from './db.js';
import { qs, icon, productCard, setupNotice, emptyHTML, errorMessage } from './ui-helpers.js';

await initLayout();
if (!isConfigured) {
  qs('#configuration-notice').innerHTML = setupNotice();
  qs('#home-categories').innerHTML = emptyHTML('Your collections will appear here', 'Connect Supabase to load categories from your database.');
  qs('#featured-products').innerHTML = emptyHTML('Your featured products will appear here', 'No demonstration products are hardcoded into this website.');
  qs('#new-products').innerHTML = ''; qs('#new-products').closest('section').hidden = true;
} else {
  try {
    const [categories, products] = await Promise.all([fetchCategories(), fetchProducts()]);
    qs('#home-categories').innerHTML = categories.length ? categories.map(category => `<a class="category-card" href="catalog.html?category=${encodeURIComponent(category.slug)}">${icon('gift')}<span>${category.name}<span aria-hidden="true">→</span></span></a>`).join('') : emptyHTML('No categories yet', 'Add your first category from the admin dashboard.');
    const featured = products.filter(product => product.is_featured).slice(0, 4);
    qs('#featured-products').innerHTML = featured.length ? featured.map(productCard).join('') : emptyHTML('Your collection is waiting', 'Add products in the admin dashboard and mark favourites as featured.');
    qs('#new-products').innerHTML = products.length ? products.slice(0, 4).map(productCard).join('') : ''; qs('#new-products').closest('section').hidden = !products.length;
  } catch (error) {
    qs('#configuration-notice').innerHTML = `<div class="error-box">${errorMessage(error)}</div>`;
    qs('#home-categories').innerHTML = emptyHTML('Collections unavailable', 'Please try again shortly.');
    qs('#featured-products').innerHTML = ''; qs('#new-products').innerHTML = '';
  }
}
