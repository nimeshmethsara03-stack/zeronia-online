import { WHATSAPP_NUMBER } from './config.js';
import { money } from './utils.js';
export function whatsappOrderURL(order, items) {
  const lines = [`Hello ZERONIA, I have placed an order on your website.`, '', `ORDER: ${order.order_number}`, `STATUS: ${order.status}`, '', 'ITEMS:'];
  items.forEach((item, index) => lines.push(`${index + 1}. ${item.product_name} (${item.product_sku})`, `   Qty: ${item.quantity} × ${money(item.unit_price)} = ${money(item.line_total)}`));
  lines.push('', `Subtotal: ${money(order.subtotal)}`, `Delivery: ${money(order.delivery_fee)}`, `TOTAL: ${money(order.total)}`, '', `Name: ${order.customer_name}`, `Mobile: ${order.mobile_number}`);
  if (order.whatsapp_number) lines.push(`WhatsApp: ${order.whatsapp_number}`);
  lines.push(`Address: ${order.delivery_address}, ${order.city}`);
  if (order.delivery_instructions) lines.push(`Delivery instructions: ${order.delivery_instructions}`);
  if (order.gift_message) lines.push(`Gift message: ${order.gift_message}`);
  lines.push('', 'Payment: Cash on Delivery', 'Please confirm my order. Thank you.');
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join('\n'))}`;
}
