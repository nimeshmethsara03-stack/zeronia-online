import { initLayout } from './components.js';
import { isConfigured } from './supabase.js';
import { fetchProduct, fetchProducts } from './db.js';
import { qs, escapeHTML, imageHTML, priceHTML, productCard, setupNotice, emptyHTML, errorMessage, money } from './ui-helpers.js';
await initLayout();
const id = new URLSearchParams(location.search).get('id');
if (!isConfigured) { qs('#configuration-notice').innerHTML = setupNotice(); qs('#product-detail').innerHTML = emptyHTML('Product unavailable', 'Connect Supabase to load product details.'); }
else if (!id) { qs('#product-detail').innerHTML = emptyHTML('Product not found', 'Return to the shop to browse the collection.', '<a class="btn btn-primary" href="catalog.html">Back to shop</a>'); }
else {
  try {
    const product = await fetchProduct(id);
    if (!product) { qs('#product-detail').innerHTML = emptyHTML('Product not found', 'It may have been removed or deactivated.', '<a class="btn btn-primary" href="catalog.html">Back to shop</a>'); }
    else {
      document.title = `${product.name} — ZERONIA`; qs('#product-crumb').textContent = product.name;
      const stock = Number(product.stock_quantity); const available = stock > 0;
      qs('#product-detail').innerHTML = `<div class="product-detail"><div class="product-detail-media">${imageHTML(product)}</div><div class="product-detail-copy"><span class="eyebrow">${escapeHTML(product.categories?.name || 'ZERONIA collection')}</span><h1>${escapeHTML(product.name)}</h1><div class="detail-price">${priceHTML(product)}</div><p class="detail-description">${escapeHTML(product.description || 'A thoughtfully selected piece from ZERONIA.')}</p><dl class="detail-meta"><dt>Product code</dt><dd>${escapeHTML(product.sku)}</dd><dt>Availability</dt><dd>${available ? `${stock} in stock` : 'Currently unavailable'}</dd><dt>Delivery</dt><dd>Calculated at checkout</dd></dl><div class="field"><span class="field-label">Quantity</span><div class="qty-control"><button type="button" id="qty-minus" aria-label="Decrease quantity">−</button><input id="detail-qty" type="number" min="1" max="${Math.max(1, stock)}" value="1" aria-label="Quantity"><button type="button" id="qty-plus" aria-label="Increase quantity">+</button></div></div><div class="detail-actions"><button class="btn btn-outline" data-add-cart="${product.id}" id="detail-add" ${!available ? 'disabled' : ''}>Add to cart</button><button class="btn btn-primary" data-buy-now="${product.id}" id="detail-buy" ${!available ? 'disabled' : ''}>Buy now · Cash on Delivery</button></div><p class="small muted">Final price and stock are securely checked again when your order is placed.</p></div></div>`;
      const qty = qs('#detail-qty'); const sync = () => { qs('#detail-add').dataset.qty = qty.value; qs('#detail-buy').dataset.qty = qty.value; };
      qs('#qty-minus').addEventListener('click', () => { qty.value = Math.max(1, Number(qty.value) - 1); sync(); });
      qs('#qty-plus').addEventListener('click', () => { qty.value = Math.min(stock || 1, Number(qty.value) + 1); sync(); }); qty.addEventListener('input', sync); sync();
      const related = (await fetchProducts()).filter(row => row.id !== id && row.category_id === product.category_id).slice(0, 4);
      qs('#related-products').innerHTML = related.map(productCard).join('');
    }
  } catch (error) { qs('#product-detail').innerHTML = `<div class="error-box">${errorMessage(error)}</div>`; }
}
