import { createClient } from '../vendor/supabase.js';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';

export const isConfigured = SUPABASE_URL.startsWith('https://') && !SUPABASE_URL.includes('YOUR_') && SUPABASE_ANON_KEY.length > 40 && !SUPABASE_ANON_KEY.includes('YOUR_');
let client;
export const getSupabase = () => {
  if (!isConfigured) throw new Error('Supabase is not configured yet. Follow SETUP_SINHALA.md to connect your project.');
  if (!client) client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
  return client;
};
