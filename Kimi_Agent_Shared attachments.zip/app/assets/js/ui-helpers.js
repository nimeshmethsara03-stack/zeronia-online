export * from './utils.js';
export const emptyHTML = (title, text, action = '') => `<div class="empty-state"><h3>${title}</h3><p class="muted">${text}</p>${action}</div>`;
