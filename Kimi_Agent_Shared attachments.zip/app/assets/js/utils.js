export const money = value => `LKR ${Number(value || 0).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const escapeHTML = value => String(value ?? '').replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
export const qs = (selector, root = document) => root.querySelector(selector);
export const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];

const paths = {
  gift: '<path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/>',
  bag: '<path d="M6 8h12l1 14H5L6 8zM9 9V6a3 3 0 0 1 6 0v3"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  whatsapp: '<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2.2-5.2A8.5 8.5 0 1 1 21 11.5z"/><path d="M8 8c1 4 4 7 8 8l1-2-3-1-1 1c-2-1-3-2-4-4l1-1-1-3z"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  box: '<path d="m21 8-9 5-9-5 9-5 9 5zM3 8v9l9 5 9-5V8M12 13v9"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4L16.5 3.5z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15M10 11v6M14 11v6"/>',
  orders: '<path d="M6 2h12v20H6zM9 6h6M9 10h6M9 14h4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1z"/>',
  logout: '<path d="M10 17l5-5-5-5M15 12H3M15 3h6v18h-6"/>',
  upload: '<path d="M12 16V3M7 8l5-5 5 5M4 15v6h16v-6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 22a8 8 0 0 1 16 0"/>',
};
export const icon = (name, label = '') => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="${label ? 'false' : 'true'}"${label ? ` role="img" aria-label="${escapeHTML(label)}"` : ''}>${paths[name] || paths.gift}</svg>`;
export const placeholder = () => `<div class="product-placeholder" aria-label="No product image">${icon('gift')}</div>`;
export const imageHTML = (product, className = '') => product.image_url ? `<img src="${escapeHTML(product.image_url)}" alt="${escapeHTML(product.name)}" loading="lazy" class="${className}">` : placeholder();
export const priceHTML = product => `<div class="price"><span>${money(product.discount_price ?? product.regular_price)}</span>${product.discount_price ? `<del>${money(product.regular_price)}</del>` : ''}</div>`;
export const toast = (message, type = 'success') => {
  let region = qs('.toast-region');
  if (!region) { region = document.createElement('div'); region.className = 'toast-region'; region.setAttribute('aria-live', 'polite'); document.body.append(region); }
  const item = document.createElement('div'); item.className = `toast ${type}`; item.textContent = message; region.append(item);
  setTimeout(() => item.remove(), 4200);
};
export const productCard = product => {
  const stock = Number(product.stock_quantity);
  const available = product.is_active && stock > 0;
  return `<article class="product-card">
    <a class="product-media" href="product.html?id=${encodeURIComponent(product.id)}" aria-label="View ${escapeHTML(product.name)}">
      ${imageHTML(product)}${product.discount_price ? '<span class="product-badge">Special price</span>' : ''}
    </a>
    <div class="product-info"><span class="product-category">${escapeHTML(product.categories?.name || 'Collection')}</span>
      <h3 class="product-name"><a href="product.html?id=${encodeURIComponent(product.id)}">${escapeHTML(product.name)}</a></h3>
      ${priceHTML(product)}<div class="stock-note ${stock > 0 && stock <= 5 ? 'stock-low' : ''}">${!available ? 'Currently unavailable' : stock <= 5 ? `Only ${stock} left` : 'In stock'}</div>
      <div class="product-actions"><button class="btn btn-outline btn-sm" data-add-cart="${product.id}" ${!available ? 'disabled' : ''}>Add to cart</button><button class="btn btn-primary btn-sm" data-buy-now="${product.id}" ${!available ? 'disabled' : ''}>Buy now</button></div>
    </div></article>`;
};
export const setupNotice = () => `<div class="setup-notice"><p><strong>Connect your Supabase project to load the live catalog.</strong><br><span class="small">Add your public URL and anon key in <code>assets/js/config.js</code>, then run the supplied SQL schema.</span></p><a class="btn btn-primary btn-sm" href="SETUP_SINHALA.md">Setup guide</a></div>`;
export const errorMessage = error => error?.message || 'Something went wrong. Please check your connection and try again.';
export const safeJSON = (value, fallback) => { try { return JSON.parse(value) ?? fallback; } catch { return fallback; } };
