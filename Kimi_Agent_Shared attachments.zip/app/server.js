import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.md': 'text/plain; charset=utf-8', '.sql': 'text/plain; charset=utf-8' };
const cleanRoutes = { '/': '/index.html', '/shop': '/catalog.html', '/product': '/product.html', '/cart': '/cart.html', '/checkout': '/checkout.html', '/confirmation': '/confirmation.html', '/about': '/about.html', '/contact': '/contact.html', '/admin': '/admin.html' };
http.createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const requested = cleanRoutes[pathname] || pathname;
    const file = path.resolve(root, `.${requested}`);
    if (!file.startsWith(root + path.sep) || pathname.includes('..')) { res.writeHead(403); res.end('Forbidden'); return; }
    const info = await stat(file); if (!info.isFile()) throw new Error('Not file');
    const body = await readFile(file);
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' https: data:; connect-src 'self' https: wss:; frame-ancestors 'self'; base-uri 'self'; form-action 'self'", 'Cache-Control': path.extname(file) === '.html' ? 'no-cache' : 'public, max-age=3600' });
    res.end(body);
  } catch { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Page not found'); }
}).listen(Number(process.env.PORT || 3000), '0.0.0.0', () => console.log('ZERONIA store listening on port', process.env.PORT || 3000));
