import { createClient } from 'npm:@supabase/supabase-js@2.49.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': Deno.env.get('ALLOWED_ORIGIN') || '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};
const response = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: corsHeaders });
const text = (value: unknown, max: number) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const validPhone = (value: string) => /^[0-9+()\-\s]{7,20}$/.test(value);

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return response({ error: 'Method not allowed' }, 405);
  try {
    const contentLength = Number(req.headers.get('content-length') || 0);
    if (contentLength > 32_000) return response({ error: 'Request is too large.' }, 413);
    const raw = await req.text();
    if (raw.length > 32_000) return response({ error: 'Request is too large.' }, 413);
    const body = JSON.parse(raw);
    const url = Deno.env.get('SUPABASE_URL');
    const secretKeys = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}');
    const serviceKey = secretKeys.default || Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!url || !serviceKey) return response({ error: 'Order service is not configured.' }, 500);
    const supabase = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

    // Basic database-backed abuse protection: 5 attempts per IP hash per 10 minutes.
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const salt = Deno.env.get('RATE_LIMIT_SALT') || 'change-this-rate-limit-salt';
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${salt}:${ip}`));
    const rateKey = Array.from(new Uint8Array(digest)).map(byte => byte.toString(16).padStart(2, '0')).join('');
    const { data: allowed, error: rateError } = await supabase.rpc('check_order_rate', { p_key: rateKey, p_limit: 5, p_window_seconds: 600 });
    if (rateError) throw rateError;
    if (!allowed) return response({ error: 'Too many order attempts. Please wait 10 minutes and try again.' }, 429);

    const customer = body?.customer || {};
    const cleanCustomer = {
      customer_name: text(customer.customer_name, 120), mobile_number: text(customer.mobile_number, 20),
      whatsapp_number: text(customer.whatsapp_number, 20), delivery_address: text(customer.delivery_address, 500),
      city: text(customer.city, 120), delivery_instructions: text(customer.delivery_instructions, 500), gift_message: text(customer.gift_message, 500),
    };
    if (cleanCustomer.customer_name.length < 2 || !validPhone(cleanCustomer.mobile_number) ||
        (cleanCustomer.whatsapp_number && !validPhone(cleanCustomer.whatsapp_number)) ||
        cleanCustomer.delivery_address.length < 5 || cleanCustomer.city.length < 2) {
      return response({ error: 'Please check your name, phone number and delivery address.' }, 400);
    }
    if (!Array.isArray(body?.items) || body.items.length < 1 || body.items.length > 30) return response({ error: 'Your cart is empty or too large.' }, 400);
    const ids = new Set<string>();
    const items = body.items.map((item: any) => {
      if (typeof item?.id !== 'string' || !/^[0-9a-f-]{36}$/i.test(item.id) || !Number.isInteger(item?.qty) || item.qty < 1 || item.qty > 99) throw new Error('Invalid cart item.');
      if (ids.has(item.id)) throw new Error('Duplicate cart item.'); ids.add(item.id);
      return { id: item.id, qty: item.qty };
    });
    const key = text(body?.idempotency_key, 100);
    if (!/^[0-9a-f-]{36}$/i.test(key)) return response({ error: 'Invalid submission key.' }, 400);

    // The RPC runs as one transaction. Browser-supplied prices and totals are never accepted.
    const { data, error } = await supabase.rpc('create_store_order', { p_customer: cleanCustomer, p_items: items, p_idempotency: key });
    if (error) return response({ error: error.message || 'The order could not be saved.' }, 400);
    if (!data?.order?.order_number) return response({ error: 'The database did not confirm the order.' }, 500);
    return response(data, 201);
  } catch (error) {
    console.error('create-order error', error);
    return response({ error: error instanceof Error && error.message.startsWith('Invalid') ? error.message : 'Unable to process the order. Please try again.' }, 400);
  }
});
