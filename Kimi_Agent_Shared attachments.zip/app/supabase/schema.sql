-- ZERONIA Gift & Accessories — Supabase PostgreSQL schema
-- Run once in Supabase SQL Editor. Safe to re-run: existing tables/data are not dropped.
create extension if not exists pgcrypto;

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  slug text not null unique check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories(id) on update cascade on delete restrict,
  name text not null check (char_length(name) between 1 and 160),
  sku text not null unique check (char_length(sku) between 1 and 60),
  description text not null default '' check (char_length(description) <= 3000),
  image_url text,
  regular_price numeric(12,2) not null check (regular_price >= 0),
  discount_price numeric(12,2) check (discount_price >= 0 and discount_price < regular_price),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  is_active boolean not null default true,
  is_featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists products_category_idx on public.products(category_id);
create index if not exists products_active_created_idx on public.products(is_active, created_at desc);
create index if not exists products_featured_idx on public.products(is_featured) where is_featured = true;

create table if not exists public.authorized_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.store_settings (
  id smallint primary key default 1 check (id = 1),
  delivery_fee numeric(12,2) not null default 450 check (delivery_fee >= 0),
  logo_url text,
  updated_at timestamptz not null default now()
);
insert into public.store_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  idempotency_key text not null unique check (char_length(idempotency_key) between 16 and 100),
  customer_name text not null check (char_length(customer_name) between 2 and 120),
  mobile_number text not null check (char_length(mobile_number) between 7 and 20),
  whatsapp_number text check (whatsapp_number is null or char_length(whatsapp_number) <= 20),
  delivery_address text not null check (char_length(delivery_address) between 5 and 500),
  city text not null check (char_length(city) between 2 and 120),
  delivery_instructions text check (delivery_instructions is null or char_length(delivery_instructions) <= 500),
  gift_message text check (gift_message is null or char_length(gift_message) <= 500),
  subtotal numeric(12,2) not null check (subtotal >= 0),
  delivery_fee numeric(12,2) not null check (delivery_fee >= 0),
  total numeric(12,2) not null check (total = subtotal + delivery_fee),
  payment_method text not null default 'Cash on Delivery' check (payment_method = 'Cash on Delivery'),
  status text not null default 'Pending' check (status in ('Pending','Confirmed','Processing','Dispatched','Delivered','Cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists orders_created_idx on public.orders(created_at desc);
create index if not exists orders_status_idx on public.orders(status);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  product_sku text not null,
  product_image_url text,
  unit_price numeric(12,2) not null check (unit_price >= 0),
  quantity integer not null check (quantity between 1 and 99),
  line_total numeric(12,2) not null check (line_total = unit_price * quantity),
  created_at timestamptz not null default now()
);
create index if not exists order_items_order_idx on public.order_items(order_id);

create table if not exists public.order_rate_limits (
  rate_key text primary key,
  window_start timestamptz not null,
  request_count integer not null default 1
);

create or replace function public.set_updated_at() returns trigger
language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

do $$
declare table_name text;
begin
  foreach table_name in array array['categories','products','orders','store_settings'] loop
    execute format('drop trigger if exists set_%I_updated_at on public.%I', table_name, table_name);
    execute format('create trigger set_%I_updated_at before update on public.%I for each row execute function public.set_updated_at()', table_name, table_name);
  end loop;
end $$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.authorized_admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.authorized_admins enable row level security;
alter table public.store_settings enable row level security;
alter table public.order_rate_limits enable row level security;

-- Explicit least-privilege table grants (RLS then checks each row).
revoke all on table public.categories, public.products, public.orders, public.order_items, public.authorized_admins, public.store_settings, public.order_rate_limits from anon, authenticated;
grant select on table public.categories, public.products, public.store_settings to anon, authenticated;
grant insert, update, delete on table public.categories, public.products to authenticated;
grant select, update on table public.orders to authenticated;
grant select on table public.order_items, public.authorized_admins to authenticated;
grant update on table public.store_settings to authenticated;
grant all on table public.categories, public.products, public.orders, public.order_items, public.authorized_admins, public.store_settings, public.order_rate_limits to service_role;

-- Public can browse only active catalog rows. Only allowlisted admins can manage them.
do $$ begin
  drop policy if exists "Public active categories" on public.categories;
  create policy "Public active categories" on public.categories for select to anon, authenticated using (is_active);
  drop policy if exists "Admin manage categories" on public.categories;
  create policy "Admin manage categories" on public.categories for all to authenticated using (public.is_admin()) with check (public.is_admin());
  drop policy if exists "Public active products" on public.products;
  create policy "Public active products" on public.products for select to anon, authenticated using (is_active);
  drop policy if exists "Admin manage products" on public.products;
  create policy "Admin manage products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());
  drop policy if exists "Admin read orders" on public.orders;
  create policy "Admin read orders" on public.orders for select to authenticated using (public.is_admin());
  drop policy if exists "Admin update orders" on public.orders;
  create policy "Admin update orders" on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());
  drop policy if exists "Admin read order items" on public.order_items;
  create policy "Admin read order items" on public.order_items for select to authenticated using (public.is_admin());
  drop policy if exists "Admin read own authorization" on public.authorized_admins;
  create policy "Admin read own authorization" on public.authorized_admins for select to authenticated using (auth.uid() = user_id);
  drop policy if exists "Public store settings" on public.store_settings;
  create policy "Public store settings" on public.store_settings for select to anon, authenticated using (true);
  drop policy if exists "Admin update store settings" on public.store_settings;
  create policy "Admin update store settings" on public.store_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());
end $$;

-- Atomic order creation: locks products, checks active status/stock, uses database prices,
-- preserves item snapshots, decrements stock and prevents duplicate submissions.
create or replace function public.create_store_order(
  p_customer jsonb,
  p_items jsonb,
  p_idempotency text
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_existing public.orders%rowtype;
  v_order public.orders%rowtype;
  v_product public.products%rowtype;
  v_item jsonb;
  v_qty integer;
  v_price numeric(12,2);
  v_subtotal numeric(12,2) := 0;
  v_delivery numeric(12,2);
  v_items jsonb := '[]'::jsonb;
  v_snapshot jsonb;
begin
  if p_idempotency is null or char_length(p_idempotency) not between 16 and 100 then
    raise exception 'Invalid submission key';
  end if;
  perform pg_advisory_xact_lock(hashtext(p_idempotency));
  select * into v_existing from public.orders where idempotency_key = p_idempotency;
  if found then
    select coalesce(jsonb_agg(to_jsonb(i) order by i.created_at), '[]'::jsonb) into v_items from public.order_items i where i.order_id = v_existing.id;
    return jsonb_build_object('order', to_jsonb(v_existing), 'items', v_items, 'duplicate', true);
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) not between 1 and 30 then
    raise exception 'Order must contain between 1 and 30 products';
  end if;
  if (select count(*) from jsonb_array_elements(p_items)) <> (select count(distinct value->>'id') from jsonb_array_elements(p_items)) then
    raise exception 'Duplicate products are not allowed';
  end if;
  if nullif(trim(p_customer->>'customer_name'), '') is null or char_length(trim(p_customer->>'customer_name')) not between 2 and 120
     or nullif(trim(p_customer->>'mobile_number'), '') is null or char_length(trim(p_customer->>'mobile_number')) not between 7 and 20
     or nullif(trim(p_customer->>'delivery_address'), '') is null or char_length(trim(p_customer->>'delivery_address')) not between 5 and 500
     or nullif(trim(p_customer->>'city'), '') is null or char_length(trim(p_customer->>'city')) not between 2 and 120 then
    raise exception 'Please provide valid customer and delivery details';
  end if;

  -- First pass locks and validates every product before anything is inserted.
  for v_item in select * from jsonb_array_elements(p_items) loop
    if (v_item->>'qty') !~ '^[1-9][0-9]?$' then raise exception 'Invalid product quantity'; end if;
    begin v_product.id := (v_item->>'id')::uuid; exception when others then raise exception 'Invalid product ID'; end;
    select * into v_product from public.products where id = (v_item->>'id')::uuid for update;
    if not found or not v_product.is_active then raise exception 'A product is no longer available'; end if;
    v_qty := (v_item->>'qty')::integer;
    if v_product.stock_quantity < v_qty then raise exception 'Insufficient stock for %', v_product.name; end if;
  end loop;

  select delivery_fee into v_delivery from public.store_settings where id = 1 for update;
  if not found then raise exception 'Store delivery setting is missing'; end if;
  insert into public.orders (
    order_number, idempotency_key, customer_name, mobile_number, whatsapp_number,
    delivery_address, city, delivery_instructions, gift_message, subtotal, delivery_fee, total
  ) values (
    'ZER-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(encode(gen_random_bytes(5), 'hex'), 1, 10)),
    p_idempotency, trim(p_customer->>'customer_name'), trim(p_customer->>'mobile_number'), nullif(trim(p_customer->>'whatsapp_number'), ''),
    trim(p_customer->>'delivery_address'), trim(p_customer->>'city'), nullif(trim(p_customer->>'delivery_instructions'), ''), nullif(trim(p_customer->>'gift_message'), ''),
    0, v_delivery, v_delivery
  ) returning * into v_order;

  for v_item in select * from jsonb_array_elements(p_items) loop
    select * into v_product from public.products where id = (v_item->>'id')::uuid;
    v_qty := (v_item->>'qty')::integer;
    v_price := coalesce(v_product.discount_price, v_product.regular_price);
    v_subtotal := v_subtotal + v_price * v_qty;
    insert into public.order_items (order_id, product_id, product_name, product_sku, product_image_url, unit_price, quantity, line_total)
    values (v_order.id, v_product.id, v_product.name, v_product.sku, v_product.image_url, v_price, v_qty, v_price * v_qty);
    v_snapshot := jsonb_build_object('product_id', v_product.id, 'product_name', v_product.name, 'product_sku', v_product.sku,
      'product_image_url', v_product.image_url, 'unit_price', v_price, 'quantity', v_qty, 'line_total', v_price * v_qty);
    v_items := v_items || jsonb_build_array(v_snapshot);
    update public.products set stock_quantity = stock_quantity - v_qty where id = v_product.id;
  end loop;
  update public.orders set subtotal = v_subtotal, total = v_subtotal + v_delivery where id = v_order.id returning * into v_order;
  return jsonb_build_object('order', to_jsonb(v_order), 'items', v_items, 'duplicate', false);
end;
$$;
revoke all on function public.create_store_order(jsonb,jsonb,text) from public, anon, authenticated;
grant execute on function public.create_store_order(jsonb,jsonb,text) to service_role;

create or replace function public.check_order_rate(p_key text, p_limit integer, p_window_seconds integer)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_allowed boolean;
begin
  insert into public.order_rate_limits (rate_key, window_start, request_count) values (p_key, now(), 1)
  on conflict (rate_key) do update set
    request_count = case when public.order_rate_limits.window_start <= now() - make_interval(secs => p_window_seconds) then 1 else public.order_rate_limits.request_count + 1 end,
    window_start = case when public.order_rate_limits.window_start <= now() - make_interval(secs => p_window_seconds) then now() else public.order_rate_limits.window_start end
  returning request_count <= p_limit into v_allowed;
  delete from public.order_rate_limits where window_start < now() - interval '1 day';
  return v_allowed;
end $$;
revoke all on function public.check_order_rate(text,integer,integer) from public, anon, authenticated;
grant execute on function public.check_order_rate(text,integer,integer) to service_role;

-- Persistent public image buckets; writes are admin-only.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp']),
       ('site-assets','site-assets',true,5242880,array['image/jpeg','image/png','image/webp','image/svg+xml'])
on conflict (id) do nothing;

do $$ begin
  drop policy if exists "Public product images" on storage.objects;
  create policy "Public product images" on storage.objects for select to public using (bucket_id in ('product-images','site-assets'));
  drop policy if exists "Admin upload images" on storage.objects;
  create policy "Admin upload images" on storage.objects for insert to authenticated with check (bucket_id in ('product-images','site-assets') and public.is_admin());
  drop policy if exists "Admin update images" on storage.objects;
  create policy "Admin update images" on storage.objects for update to authenticated using (bucket_id in ('product-images','site-assets') and public.is_admin()) with check (bucket_id in ('product-images','site-assets') and public.is_admin());
  drop policy if exists "Admin delete images" on storage.objects;
  create policy "Admin delete images" on storage.objects for delete to authenticated using (bucket_id in ('product-images','site-assets') and public.is_admin());
end $$;

-- Starter categories and editable sample products. No product data is hardcoded in JavaScript.
insert into public.categories (name, slug) values
  ('Gifts','gifts'),('Accessories','accessories'),('Gift Boxes','gift-boxes'),('Bouquets','bouquets'),
  ('Soft Toys / Teddy Bears','soft-toys-teddy-bears'),('Perfumes','perfumes'),('Home Essentials','home-essentials'),
  ('Home Decorations','home-decorations'),('Other Products','other-products')
on conflict (slug) do nothing;

insert into public.products (category_id,name,sku,description,regular_price,discount_price,stock_quantity,is_featured)
select c.id, v.name, v.sku, v.description, v.price, v.discount, v.stock, v.featured from (values
  ('gifts','Moment Keepsake Gift','ZER-GFT-001','A thoughtful keepsake for birthdays, thank-yous and meaningful celebrations.',2950.00,2500.00,12,true),
  ('accessories','Everyday Elegance Accessory','ZER-ACC-001','A versatile finishing touch selected for everyday style.',1850.00,null::numeric,20,true),
  ('gift-boxes','Navy Celebration Gift Box','ZER-BOX-001','An elegant gift presentation for a memorable surprise.',4500.00,3950.00,8,true),
  ('bouquets','Beautiful Moments Bouquet','ZER-BQT-001','A charming bouquet arrangement to brighten someone’s day.',5500.00,null::numeric,6,true),
  ('soft-toys-teddy-bears','Cuddly Companion Teddy','ZER-TDY-001','A soft and lovable companion for someone special.',3200.00,null::numeric,10,false),
  ('perfumes','Signature Everyday Fragrance','ZER-PRF-001','A graceful everyday fragrance presented ready for gifting.',4900.00,4400.00,9,false),
  ('home-essentials','Thoughtful Home Essential','ZER-HME-001','A useful and attractive addition to everyday living.',2200.00,null::numeric,15,false),
  ('home-decorations','Golden Detail Home Decor','ZER-DEC-001','A refined decorative accent for a beautiful space.',3750.00,null::numeric,7,false),
  ('other-products','Little Surprise Selection','ZER-OTH-001','A delightful little surprise for any ordinary day.',1500.00,null::numeric,18,false)
) as v(slug,name,sku,description,price,discount,stock,featured)
join public.categories c on c.slug = v.slug
on conflict (sku) do nothing;

-- After creating an admin user in Authentication > Users, authorize their UUID:
-- insert into public.authorized_admins (user_id) values ('PASTE-AUTH-USER-UUID');
